# Chapter 6 — Gameplay Blueprints

Small games reveal how Bevy’s pieces click together. This chapter dissects mini-game loops and async task patterns, tracing how input, rendering, state, and background work combine into resilient prototypes. Each beat links back to the examples so you can explore the source that inspired the story.

```mermaid
graph TD
    Prototype[Prototype Idea] --> Systems[Systems & Schedules]
    Systems --> Feedback[Player Feedback]
    Feedback --> Content[Content & Assets]
    Content --> polish[Polish & Async]
    polish --> Prototype
```

## Playable Mini-Games

A single loop showcases an entire ecosystem. `examples/games/alien_cake_addict.rs` keeps focus tight: player input, collision checks, and scoring all fit inside a candy-colored feedback loop, making it the perfect entry point for new programmers. For a more traditional arcade feel, `examples/games/breakout.rs` adds bricks, physics, and paddle control, doubling as a demonstration of debug stepping when the `bevy_debug_stepping` feature is enabled. Together, these examples prove that even with minimal assets, Bevy can carry a full gameplay loop.

Production teams rarely ship games without menus or flair. `examples/games/game_menu.rs` introduces a responsive UI layer with start, settings, and quit flow. It never launches a real game but shows how to bind UI events to state transitions and timer-driven previews. The moment you need to smooth out loading, `examples/games/loading_screen.rs` steps in, demonstrating how to wait for assets to become ready, render progress UI, and transition gracefully once everything is prepared.

Visual polish matters. `examples/games/desk_toy.rs` transforms the Bevy logo into a transparent desk toy with googly eyes, illustrating how playful rendering tweaks and window configuration create delightful desk companions. `examples/games/contributors.rs` turns community stats into a bouncing particle show, reminding teams that data visualisation can be playful and informative inside the same engine.

Complex projects need to inspect and debug schedules. `examples/games/stepping.rs` moves stepping systems into their own schedule so you can pause, resume, and analyse the main loop without touching gameplay code. The pattern pairs well with the debug stepping support from the Breakout sample: together they form a toolkit for studying system order and runtime flow before bugs reach production.

Taken as a whole, these mini-games teach you how to balance gameplay, UI, loading sequences, and debug affordances in a single codebase.

## Async and Background Workflows

Some workloads don’t fit inside the main tick. `examples/async_tasks/async_compute.rs` integrates Bevy’s `AsyncComputeTaskPool`, showing how to spawn heavy tasks, poll their progress each frame, and commit results back into ECS state without blocking the renderer. Meanwhile, `examples/async_tasks/external_source_external_thread.rs` spins an external thread that runs an infinite producer, communicating over channels so gameplay sees fresh data without waiting on it.

```mermaid
graph LR
    GameSystems --> TaskPool
    TaskPool --> Polling
    Polling --> Results
    Results --> GameSystems
    ExternalThread --> Channels
    Channels --> Results
```

These patterns empower live-service features—background matchmaking, procedural generation, telemetry uploads—while keeping frame times stable. Blend them with the mini-game scaffolds and you can stream new levels, update leaderboards, or animate desk toys based on external data without introducing stalls.

## Practice Prompts
- Extend `examples/games/game_menu.rs` to launch `examples/games/alien_cake_addict.rs`, then return gracefully using the stepping approach from `examples/games/stepping.rs`.
- Feed the scene in `examples/games/contributors.rs` with data streamed from `examples/async_tasks/external_source_external_thread.rs`, updating bouncing avatars as the external thread reports changes.
- Integrate `examples/async_tasks/async_compute.rs` into `examples/games/breakout.rs` to offload level generation or score calculation without disrupting paddle responsiveness.

## Runbook
Start with these commands to experience the chapter, then branch into the remaining samples as inspiration strikes:

```
cargo run --example alien_cake_addict
cargo run --example breakout
cargo run --example game_menu
cargo run --example loading_screen
cargo run --example async_compute
cargo run --example external_source_external_thread
```
