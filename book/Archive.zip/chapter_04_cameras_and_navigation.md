# Chapter 4 — Cameras and Navigation

Great camera work keeps players oriented while motion systems translate input into intention. This chapter walks through Bevy’s camera toolkit and movement helpers, showing how each layer builds on the last. Every vignette links to the backing example so you can peek at the code that underpins the story.

```mermaid
graph TD
    CameraRig[Camera Rig] --> Projection[Projection]
    Projection --> Framing[Framing & Composition]
    Framing --> Layers[Layering & Order]
    Layers --> MotionAssist[Motion Assist]
    MotionAssist --> CameraRig
```

## Camera Toolkit

We begin with camera architecture. `examples/camera/custom_projection.rs` teaches how to author bespoke projection matrices so designers can experiment beyond the default perspective and orthographic options. Once the lens is chosen, `examples/camera/projection_zoom.rs` layers in zoom controls for both projection types, keeping HUD legibility and gameplay readability intact.

Composition comes next. The orbit rig in `examples/camera/camera_orbit.rs` demonstrates how pitch, yaw, and roll interplay to showcase a scene without disorienting the player. First-person projects build on that foundation using `examples/camera/first_person_view_model.rs`, which introduces near-body meshes and stabilises weapon rigs while reusing the orbit math internally.

Layering multiple views finishes the camera stack. `examples/camera/2d_on_ui.rs` renders sprites above UI panels via a second camera with a higher `order`, perfect for tactical overlays or inventory previews. When the moment calls for flair, `examples/camera/2d_screen_shake.rs` injects trauma-based camera shake, grounding the effect in easing math so intensity ramps up and decays smoothly. For top-down adventures, `examples/camera/2d_top_down_camera.rs` fuses smooth player tracking with world-space damping, creating a view that anticipates player motion instead of lagging behind.

All these patterns coexist: custom projections set the stage, layered cameras provide context, and motion effects ensure the view responds with polish.

## Movement and Navigation Patterns

Camera work is only as good as the motion that feeds it. `examples/movement/physics_in_fixed_timestep.rs` synchronises player input with a fixed-step physics loop, echoing best practices from “Fix Your Timestep!” so movement stays deterministic and responsive. Once physics is solid, `examples/movement/smooth_follow.rs` shows how to ease one entity toward another—ideal for companion drones, cinematic cameras, or UI markers.

When paired together, the fixed-timestep pipeline keeps velocity integration stable while smooth follow routines add the finishing grace notes, ensuring both cameras and entities glide instead of jitter.

```mermaid
graph LR
    Input --> FixedStep[Fixed Timestep]
    FixedStep --> PhysicsState[Physics State]
    PhysicsState --> SmoothFollow
    SmoothFollow --> CameraRig
```

## Practice Prompts
- Combine `examples/camera/first_person_view_model.rs` with `examples/movement/physics_in_fixed_timestep.rs` to keep a first-person rig steady even during tight physics manoeuvres.
- Use the layered approach from `examples/camera/2d_on_ui.rs` alongside the trauma-driven shake in `examples/camera/2d_screen_shake.rs` to create combat overlays that pulse with impact while leaving UI readable.
- Adapt the smooth follower in `examples/movement/smooth_follow.rs` to drive a cinematic camera that tracks the spline paths you prototyped in Chapter 3.

## Runbook
Start with these commands to experience the chapter’s highlights, then explore the remaining examples for deeper inspiration:

```
cargo run --example custom_projection
cargo run --example projection_zoom
cargo run --example camera_orbit
cargo run --example first_person_view_model
cargo run --example physics_in_fixed_timestep
cargo run --example smooth_follow
```
