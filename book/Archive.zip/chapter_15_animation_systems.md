# Chapter 15 — Animation Systems

Bevy’s animation stack ranges from UI clip playback to fully skinned rigs and procedural tweens. This chapter weaves those layers together so you can choreograph motion across characters, interfaces, and gameplay feedback. Each storyline references the examples that make the techniques concrete.

```mermaid
graph TD
    Keyframes[Keyframed Clips] --> Graphs[Animation Graphs]
    Graphs --> Events[Animation Events]
    Events --> Procedural[Procedural Tweens]
    Procedural --> Skins[Skinned Meshes]
    Skins --> Keyframes
```

## Character and Skeletal Animation

Clip-driven animation is the backbone of sequencing. `examples/animation/animated_ui.rs` shows how the same clip system that drives characters can animate UI properties—scaling, color, and layout timing. It highlights how animation nodes sit alongside ECS components so menus, HUDs, and in-world billboards can all reference the same animation assets used for characters, keeping timing consistent across the entire experience.

## Sprite and 2D Animation

Sprite flipbooks and atlas-driven loops were covered earlier in Chapter 7; revisit those examples (`examples/2d/sprite_sheet.rs`, `examples/2d/sprite_animation.rs`) when you need frame-based characters. They slot neatly beside the systems in this chapter: tweened easing can trigger sprite swaps, and animation events can fire particles or UI prompts while sprites change frames.

## Tweening and Procedural Motion

When keyframes are overkill, tweens step in. `examples/animation/easing_functions.rs` catalogs the easing curves bundled with Bevy, previewing how each shaping function looks in motion. `examples/animation/eased_motion.rs` then applies those curves to a moving entity, blending start and end transforms in real time. Together they provide the vocabulary for procedural motion: buttons that spring back, pickups that hover, cameras that glide into position without bespoke animation clips.

```mermaid
graph LR
    EasingFunctions --> EasedMotion
    EasedMotion --> UIClips
    UIClips --> GameFeedback
```

## Specialized Animation Techniques

Production characters need more than simple loops. Start with rig playback: `examples/animation/animated_mesh.rs`, `examples/animation/animated_mesh_control.rs`, and `examples/animation/animated_mesh_events.rs` animate skinned glTF models, layer controls on top, and emit events as clips reach key frames. When you want code-defined animation, `examples/animation/animated_transform.rs` generates curves directly against the `Transform` component.

Complex scenes benefit from graphs and masks. `examples/animation/animation_graph.rs` renders the animation graph while demonstrating blend nodes, state transitions, and parameter control. `examples/animation/animation_masks.rs` restricts clips to subsets of the skeleton—upper-body emotes layered over lower-body locomotion, for example.

Events glue systems together. `examples/animation/animation_events.rs` triggers custom logic when clips hit markers, perfect for synchronising sound effects or gameplay cues. `examples/animation/color_animation.rs` animates colors across different color spaces, showing how splines can add flourish to UI or magical effects.

Custom rigs matter too. `examples/animation/custom_skinned_mesh.rs` builds a skinned mesh entirely from code, matching the structure of `examples/animation/gltf_skinned_mesh.rs`, which loads the same rig from glTF. Morph targets add facial expressions or shape-shifting: `examples/animation/morph_targets.rs` plays a morph animation and exposes how to read morph target names for debugging or personalisation.

```mermaid
graph LR
    SkinnedClips --> AnimationGraph
    AnimationGraph --> Masks
    Masks --> Events
    Events --> MorphTargets
    MorphTargets --> SkinnedClips
```

## Practice Prompts
- Drive a HUD transition by combining `examples/animation/animated_ui.rs` with easing profiles from `examples/animation/eased_motion.rs` so menu panels feel responsive.
- Blend a locomotion set with emotes using `examples/animation/animation_graph.rs` and `examples/animation/animation_masks.rs`, firing hit reactions via `examples/animation/animation_events.rs`.
- Prototype a shapeshifting character by extending `examples/animation/morph_targets.rs`, then swap in a code-defined rig from `examples/animation/custom_skinned_mesh.rs` to test custom meshes.

## Runbook
Try these examples to get comfortable before mixing techniques in your project:

```
cargo run --example animated_ui
cargo run --example easing_functions
cargo run --example animated_mesh
cargo run --example animation_graph
cargo run --example animation_masks
cargo run --example morph_targets
```
