# Chapter 24 — Target Platforms

Shipping to new platforms means adapting entry points, runtime constraints, and build tooling. This chapter digs into mobile integration and `no_std` support so you can bring Bevy to phones, tablets, or constrained environments. Each paragraph links back to the examples that prove the workflow.

```mermaid
graph TD
    MobileEntry[Mobile Entry] --> TouchUI[Touch/UI]
    TouchUI --> AudioIntegration[Audio Integration]
    AudioIntegration --> PlatformEvents[Platform Events]
    PlatformEvents --> Embedded[Embedded/No-Std]
    Embedded --> MobileEntry
```

## Mobile Platforms

The mobile example lives in the `examples/mobile` crate. `examples/mobile/src/main.rs` is the iOS entry point, showing how to bootstrap Bevy inside an Apple application bundle—tying into Xcode projects and UIApplication lifecycles. `examples/mobile/src/lib.rs` hosts the Bevy app logic: a 3D scene with a UI button and background audio, demonstrating how touch input, rendering, and audio playback work together on mobile hardware.

This separation mirrors production setups: native shells handle platform-specific glue while shared Rust libraries deliver gameplay, UI, and audio across iOS and Android builds.

## no_std and Embedded Targets

Constrained platforms often require `no_std`. `examples/no_std/library/src/lib.rs` illustrates the patterns for creating a `no_std`-compatible Bevy library: annotate with `#![no_std]`, manage allocator choices, and expose core systems without depending on the full standard library. It becomes the foundation for headless simulations, embedded devices, or custom runners where standard I/O is unavailable.

## Practice Prompts
- Embed `examples/mobile/src/lib.rs` into a native Android shell, mirroring the iOS entry pattern to keep UI and audio consistent across both mobile ecosystems.
- Build a minimal server binary by starting from `examples/no_std/library/src/lib.rs`, adding only the systems required for simulation while integrating with the diagnostic tooling discussed in earlier chapters.

## Runbook
Experiment with platform-specific builds by exploring:

```
cargo run --example mobile --target aarch64-apple-ios-sim
cargo run --example no_std_library
```
