# Chapter 11 — Lighting and Atmosphere

Lighting defines mood; atmosphere sustains it. This chapter shows how Bevy’s lighting stack—spotlights, area lights, soft shadows, and transmission—connects seamlessly with fog, skyboxes, and screen-space techniques so a scene can breathe. Each vignette references the example that powers the idea.

```mermaid
graph TD
    Lights[Lights & Shadows] --> Materials[Material Response]
    Materials --> Atmosphere[Atmospheric Medium]
    Atmosphere --> Reflections[Reflections & Sky]
    Reflections --> Lights
```

## Lighting, Shadows, and Exposure

Start with the playbook for varied fixtures. `examples/3d/spotlight.rs` demonstrates tight-beam spotlights that direct attention, while `examples/3d/spherical_area_lights.rs` widens coverage with radius-sensitive point lights. Texture-driven lights beam silhouettes via `examples/3d/light_textures.rs`, perfect for stained glass or projector effects. Mixed pipelines surface through `examples/3d/mixed_lighting.rs`, which merges baked and dynamic lighting so static props bask in precomputed GI while dynamic actors keep their own shadows.

Softness and realism come from shadow tuning. `examples/3d/pcss.rs` explores percentage-closer soft shadows, showing how filter kernel sizes shape penumbras. When you need advanced control, `examples/3d/solari.rs` introduces Bevy Solari for real-time ray-traced lighting, letting you experiment with physically based shadows on high-end hardware. Materials respond to light in nuanced ways: `examples/3d/transmission.rs` illustrates subsurface transmission controls, giving skin, wax, or leaves believable backlighting with adjustable thickness and roughness.

Combine these techniques and you can layer directional, spot, and area lights while adjusting softness and transmission to fit any art direction, from stylised dioramas to photorealistic vignettes.

## Atmosphere, Fog, and Environment Maps

Lighting isn’t complete until it meets air. `examples/3d/atmospheric_fog.rs` and `examples/3d/volumetric_fog.rs` step beyond simple distance fog: atmospheric fog spreads an aerial perspective across the scene, and volumetric fog threads light shafts through god rays. Fog becomes malleable in `examples/3d/fog_volumes.rs`, where density textures sculpt fog volumes—here the Stanford bunny—inside the world.

For planetary vibes, `examples/3d/atmosphere.rs` simulates PBR atmospheric scattering, giving sky gradients and horizon glow that react to sun position. Skyboxes stay dynamic thanks to `examples/3d/skybox.rs`, which loads cubemaps and cycles compressed formats, while `examples/3d/rotate_environment_map.rs` keeps environment reflections locked when you rotate the sky. To ensure reflections capture screen-space details, `examples/3d/ssr.rs` enables screen-space reflections, blending them with other sources for glossy surfaces.

Motion adds life. `examples/3d/scrolling_fog.rs` scrolls fog density textures over time, making weather systems drift realistically.

```mermaid
graph LR
    FogDensity --> LightingScatter
    LightingScatter --> Skybox
    Skybox --> SSR
    SSR --> FogDensity
```

## Practice Prompts
- Pair `examples/3d/pcss.rs` with `examples/3d/volumetric_fog.rs` to soften shadows while letting god rays pierce the fog.
- Combine `examples/3d/transmission.rs` with `examples/3d/scrolling_fog.rs` to light semi-translucent foliage that sways within moving fog banks.
- Rotate environment maps with `examples/3d/rotate_environment_map.rs` while using screen-space reflections from `examples/3d/ssr.rs` to keep metallic surfaces grounded in the current sky.

## Runbook
Experience the lighting toolkit first-hand using the commands below, then weave the techniques together in your scenes:

```
cargo run --example spotlight
cargo run --example spherical_area_lights
cargo run --example pcss
cargo run --example transmission
cargo run --example volumetric_fog
cargo run --example ssr
```
