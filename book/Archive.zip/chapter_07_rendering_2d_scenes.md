# Chapter 7 — Rendering 2D Scenes

Expressive 2D worlds emerge when sprites, text, and custom meshes harmonise. This chapter walks from basic sprite work through textured meshes and bespoke pipelines, showing how each technique layers onto the previous one. Every paragraph references the example that demonstrates the concept, so you can dive into the code behind the narrative.

```mermaid
graph TD
    SpriteCore[Sprite Core] --> AnimSystems[Animation]
    AnimSystems --> Atlases[Texture Atlases]
    Atlases --> MeshPrimitives[Mesh Primitives]
    MeshPrimitives --> CustomPipelines[Custom Pipelines]
    CustomPipelines --> Presentation[Presentation & Polish]
    Presentation --> SpriteCore
```

## Sprites and Shape Primitives

The 2D journey begins with the simplest possible render: `examples/2d/sprite.rs` delivers a single textured sprite to screen, proving the pipeline from asset load to draw call. Motion arrives through `examples/2d/move_sprite.rs`, which animates position each frame and shows how transforms update alongside sprites. Scaling, flipping, and slicing refine presentation as `examples/2d/sprite_scale.rs`, `examples/2d/sprite_flipping.rs`, and `examples/2d/sprite_slice.rs` demonstrate fitting textures, mirroring art, and reusing widgets at multiple resolutions.

Animation breathes life into characters. `examples/2d/sprite_animation.rs` responds to keyboard events by stepping frames; `examples/2d/sprite_sheet.rs` goes further by using a texture atlas to loop animation sequences automatically. When building UI overlays or scoreboard panels, `examples/2d/text2d.rs` integrates text into the same scene graph, inheriting transforms so text can spin or scale with your sprites.

Atlases and tiling keep assets clean. `examples/2d/texture_atlas.rs` batch-builds sprite sheets from folders, exploring padding strategies that prevent bleeding. For pixel-perfect presentation, `examples/2d/pixel_grid_snap.rs` renders to an intermediate texture, snapping the final image to the grid so retro art styles stay crisp.

Shapes and mesh primitives let you leave textures behind. `examples/2d/2d_shapes.rs` uses Bevy’s primitive library to build meshes, each tinted via material colors, while `examples/2d/mesh2d.rs` constructs meshes from rectangles. When translucency or depth sorting enters the scene, `examples/2d/mesh2d_alpha_mode.rs` illustrates how alpha modes play with transforms and the depth buffer. Curved overlays and HUD arcs rely on the UV-focused `examples/2d/mesh2d_arcs.rs` to keep textures warped correctly. CPU-driven graphics, like heatmaps or painterly effects, start with `examples/2d/cpu_draw.rs`, writing pixel data directly into textures for bespoke visuals.

Textures can do more than cover surfaces. `examples/2d/mesh2d_repeated_texture.rs` shows how to repeat textures beyond their default clamped sampling, great for tiling backgrounds or infinite scrolling ground. Texture work can also blend vertex colors with imagery. `examples/2d/mesh2d_vertex_color_texture.rs` layers per-vertex tinting over a textured rectangle so designers can grade lighting locally without extra sprites.

## Custom 2D Mesh Workflows

As projects mature, custom pipelines unlock stylistic freedom. `examples/2d/mesh2d_manual.rs` dives beneath `Material2d` to edit vertex buffers directly, injecting per-vertex colors without high-level helpers. When artists provide glTF assets with extra attributes, `examples/2d/custom_gltf_vertex_attribute.rs` demonstrates how to extract those custom vertex streams and render them in 2D, bridging DCC tools and runtime shaders.

Wireframes provide elegant debugging. `examples/2d/wireframe_2d.rs` displays mesh edges, invaluable when tweaking collision hulls or verifying procedural geometry.

These advanced workflows loop back to the sprite foundations: custom buffers can carry the same atlas coordinates you used earlier, and wireframes often overlay animated sprites to examine hitboxes or motion arcs.

```mermaid
graph LR
    AtlasData --> ManualMesh
    ManualMesh --> CustomAttributes
    CustomAttributes --> WireframeDebug
    WireframeDebug --> SpriteLayer
```

## Practice Prompts
- Combine `examples/2d/texture_atlas.rs` with `examples/2d/mesh2d_repeated_texture.rs` to build a modular UI skin that mixes tiled backgrounds with atlas-driven buttons.
- Extend `examples/2d/cpu_draw.rs` so the CPU-generated texture feeds into `examples/2d/mesh2d_manual.rs`, layering real-time data visualisations over player avatars.
- Pair `examples/2d/custom_gltf_vertex_attribute.rs` with `examples/2d/wireframe_2d.rs` to debug glTF imports by rendering both textured and wireframe views simultaneously.

## Runbook
Start with these demos to experience the chapter’s techniques before expanding to the rest:

```
cargo run --example sprite
cargo run --example sprite_sheet
cargo run --example 2d_shapes
cargo run --example mesh2d_manual
cargo run --example custom_gltf_vertex_attribute
```
