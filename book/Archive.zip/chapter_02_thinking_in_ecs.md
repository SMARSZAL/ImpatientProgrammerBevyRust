# Chapter 2 — Thinking in ECS

Bevy’s power lies in how entities, components, and systems braid together. Rather than paging through APIs, this chapter tells the story of how data, behaviour, and scheduling collaborate to keep a world alive. Every scene below points to a concrete example so you can jump from narrative to source in a single heartbeat.

```mermaid
graph TD
    Entity[Entity] --> Component[Component]
    Component --> System[System]
    System --> Schedule[Schedule]
    Schedule --> WorldTick[World Tick]
    WorldTick --> Feedback[Change Detection]
    Feedback --> System
```

## Components, Bundles, and System Queries

The conversation starts with the guided overview in `examples/ecs/ecs_guide.rs`, which lays out how entities hold components and systems act upon their data. From there, builders reach for `examples/ecs/dynamic.rs` when components must be created at runtime; the pattern lets toolchains spawn arbitrary data without recompiling. Once the world is populated, hierarchy becomes essential—`examples/ecs/hierarchy.rs` shows how parent and child transforms propagate, letting multi-part machines pivot as one.

Reactive behaviour keeps scenes honest. `examples/ecs/change_detection.rs` teaches systems to wake only when data truly shifts, while `examples/ecs/removal_detection.rs` closes the loop by signalling when components vanish. When data is scoped to particular game phases, `examples/ecs/state_scoped.rs` automatically despawns state-specific entities so menus, levels, and overlays clean up after themselves.

Lifecycle hooks help data police itself. `examples/ecs/component_hooks.rs` demonstrates how components can validate or initialise values the moment they attach to entities, and `examples/ecs/immutable_components.rs` records the cases where immutable data still participates in updates. Observability extends beyond hooks: `examples/ecs/observers.rs` wires custom observers that listen to component changes, while `examples/ecs/observer_propagation.rs` cascades those events across hierarchies.

Expressive queries glue the data graph together. The struct-based approach from `examples/ecs/custom_query_param.rs` replaces tuple juggling with named fields so complex systems remain legible. When behaviour should adapt to type parameters, `examples/ecs/generic_system.rs` shows how generics keep logic DRY across multiple components. Heavy worlds stay responsive thanks to the iterators in `examples/ecs/parallel_query.rs`, which fan queries across threads, and the pairwise scans in `examples/ecs/iter_combinations.rs`, which power proximity checks without extra bookkeeping.

```mermaid
graph LR
    ChangeDetection --> SystemsReact
    ComponentHooks --> SystemsReact
    Observers --> SystemsReact
    SystemsReact --> WorldState
    WorldState --> Queries
    Queries --> SystemsReact
```

## Resources, Events, and Global Coordination

Sometimes the world needs a central voice. `examples/ecs/fallible_params.rs` illustrates how systems can politely decline to run when critical resources are missing, keeping error handling deliberate instead of panicked. When information should ripple outward, the propagation pipeline in `examples/ecs/observer_propagation.rs` forwards events through entity hierarchies so parent controllers and child widgets stay in sync.

Those techniques pair naturally with the logging bridge from `examples/app/log_layers_ecs.rs` back in Chapter 1: together they let you surface authoritative alerts, buffer them in resources, and let observers broadcast updates to whichever systems care most.

## Advanced ECS Patterns

Once the core vocabulary is fluent, advanced phrasing opens up. Scheduling control begins with `examples/ecs/custom_schedule.rs`, which nests custom phases alongside Bevy’s built-in Update and Last stages. When entities need to disappear without being destroyed, `examples/ecs/entity_disabling.rs` keeps them dormant, ready to rejoin gameplay later.

Robust applications plan for mishaps. `examples/ecs/error_handling.rs` shows how fallible systems lean on Rust’s `Result` ergonomics, while `examples/ecs/fallible_params.rs` (seen above) prevents invalid access in the first place. Temporal precision arrives via `examples/ecs/fixed_timestep.rs`, ensuring physics or simulation beats remain consistent no matter the frame rate.

Runtime creativity follows. Hot-reload toolchains lean on `examples/ecs/hotpatching_systems.rs` to swap system logic without downtime, whereas messaging-heavy games start with `examples/ecs/message.rs` and graduate to `examples/ecs/send_and_receive_messages.rs` when a single system must both enqueue and consume messages in order. To keep those messages in the right order, `examples/ecs/run_conditions.rs` and `examples/ecs/nondeterministic_system_order.rs` spell out how to express dependencies so parallel execution never surprises you.

One-shot logic deserves its own spotlight: `examples/ecs/one_shot_systems.rs` demonstrates triggers that fire once and retire, perfect for cutscene cues. Entity relationships stretch beyond simple parent and child links—`examples/ecs/relationships.rs` maps richer graphs while staying query-friendly.

Starting and stopping cleanly rounds out the toolkit. `examples/ecs/startup_system.rs` captures work that should happen once at boot; `examples/ecs/system_closure.rs` proves closures can stand in as systems for rapid prototyping; `examples/ecs/system_param.rs` introduces custom `SystemParam` bundles so repetitive lookups collapse into one argument. When data needs to flow through multiple processing steps, `examples/ecs/system_piping.rs` chains functions into a single pipeline, and debugging sessions lean on `examples/ecs/system_stepping.rs` to walk systems in the order they execute.

All of these ideas converge in relationships-first scheduling: messaging, run conditions, and fixed timesteps ensure the machine hums while hotpatching keeps it malleable enough to evolve mid-flight.

```mermaid
graph TD
    CustomSchedule --> RunConditions
    RunConditions --> Messages
    Messages --> OneShot
    OneShot --> Relationships
    Relationships --> Hotpatching
    Hotpatching --> DebugStepping
    DebugStepping --> CustomSchedule
```

## Practice Prompts
- Combine the observer patterns from `examples/ecs/observers.rs` and the disable-and-resume workflow in `examples/ecs/entity_disabling.rs` to create stealth AI that sleeps until alerted.
- Prototype a modular combat system by chaining `examples/ecs/system_piping.rs` with the messaging loop from `examples/ecs/message.rs`, then hot swap behaviours using `examples/ecs/hotpatching_systems.rs`.
- Build a deterministic simulation by pairing `examples/ecs/fixed_timestep.rs` with the change detection in `examples/ecs/change_detection.rs`, ensuring only meaningful updates consume CPU.

## Runbook
Explore the narrative hands-on with a focused sampling, then branch into the remaining examples as questions arise:

```
cargo run --example ecs_guide
cargo run --example custom_query_param
cargo run --example observer_propagation
cargo run --example custom_schedule
cargo run --example run_conditions
cargo run --example system_stepping
```
